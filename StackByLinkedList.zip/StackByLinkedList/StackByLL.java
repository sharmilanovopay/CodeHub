package physicalDS;

import physicalDS.SingleNode;
import physicalDS.SLL;

import java.util.function.DoubleToIntFunction;

public class StackByLL {

    SLL list ;

    public static void main(String[] args) {

        StackByLL Stack = new StackByLL();
        System.out.println("Stack.isEmpty() = "+Stack.isEmpty());
        for(int i=0;i<10;i++) {
            Stack.push(i*10);
        }
        Stack.peek();
        for(int i=0;i<3;i++) {
            Stack.pop();
        }
        Stack.peek();
        Stack.deleteStack();
        System.out.println("Stack.isEmpty() = "+Stack.isEmpty());

    }

    public StackByLL() {
       list = new SLL();
    }

    public boolean isEmpty(){
        return (list.getHead()==null);
    }

    public void deleteStack(){
        list.setHead(null);
    }

    public void peek(){
        if(!isEmpty()){
            System.out.println("the top item to be peeked is : "+ list.getHead().getValue());
        }else{
            System.out.println("empty LL");
        }
    }

    public void push(int value){
        if(list.getHead()==null){
            list.createSLL(value);
         }else {
            list.insertInLinkedList(value,0);
        }
        System.out.println("inserted "+value+" in stack");
    }

    public void pop(){
        if(isEmpty()){
            System.out.println("empty already, cant pop");
        }else {
            System.out.println(list.getHead().getValue());
            list.deletionOfNode(0);

        }
    }
}
