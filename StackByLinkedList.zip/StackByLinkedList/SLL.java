package physicalDS;
import physicalDS.SingleNode;
public class SLL {
    private SingleNode head;
    private SingleNode tail;
    private int size;

    public SingleNode createSLL(int value) {
        head = new SingleNode();
        SingleNode node = new SingleNode();
        head = node;
        node.setValue(value);
        node.setNext(null);
        head = node;
        tail = node;
        size = 1;
        return head;
    }

    public SingleNode getHead() {
        return head;
    }

    public void setHead(SingleNode head) {
        this.head = head;
    }

    public SingleNode getTail() {
        return tail;
    }

    public void setTail(SingleNode tail) {
        this.tail = tail;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }


    public void insertInLinkedList(int nodeValue, int location) {
        SingleNode node = new SingleNode();
        node.setValue(nodeValue);
        if (location == 0) {// insert at first position
            node.setNext(head);
            head = node;
        } else if (location >= size) {// insert at last position
            node.setNext(null);
            tail.setNext(node);
            tail = node;
        } else {// insert at specified location
            SingleNode tempNode = head;
            int index = 0;
            while (index < location - 1) {// loop till we reach specified node
                tempNode = tempNode.getNext();
                index++;
            }//tempNode currently references to node after which we should insert new node
            SingleNode nextNode = tempNode.getNext(); //this is the immediate next node after new node
            tempNode.setNext(node);//update reference of tempNode to reference to new node
            node.setNext(nextNode);//update newly added nodes' next.
        }
        setSize(getSize() + 1);
    }

    public void deletionOfNode(int location) {
        if (location == 0) { // we want to delete first element
            head = head.getNext();
            setSize(getSize() - 1);
            if (getSize() == 0) { // if there are no more nodes in this list
                tail = null;
            }
        } else if (location >= getSize()) { //If location is not in range or equal, then delete last node
            SingleNode tempNode = head;
            for (int i = 0; i < size - 1; i++) {
                tempNode = tempNode.getNext(); //temp node points to 2nd last node
            }
            if (tempNode == head) { //if this is the only element in the list
                tail = head = null;
                setSize(getSize() - 1);
                return;
            }
            tempNode.setNext(null);
            tail = tempNode;
            setSize(getSize() - 1);

        } else { //if any inside node is to be deleted
            SingleNode tempNode = head;
            for (int i = 0; i < location - 1; i++) {
                tempNode = tempNode.getNext(); // we need to traverse till we find the location
            }
            tempNode.setNext(tempNode.getNext().getNext()); // delete the required node
            setSize(getSize() - 1);
        }//end of else
    }
}
