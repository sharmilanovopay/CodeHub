package com.testvagrant.WeatherComparator.UI;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.testvagrant.BasePage.BasePage;

public class HomePage extends BasePage{

	
	WebDriverWait wait=new WebDriverWait(driver, 15);
	Alert alert;
	
	public HomePage(WebDriver driver) throws IOException {
		PageFactory.initElements(driver, this);
	
	}
	
	public WeatherPage navigate() throws IOException {
		handleBreakingNewsAlert();
		WebElement more=driver.findElement(By.xpath("//a[@id=\"h_sub_menu\"]"));
		more.click();		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement weatherPageLink=driver.findElement(By.xpath("//a[contains(text(),\"WEATHER\")]"));
		weatherPageLink.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return new WeatherPage(driver);
	}
	
	public void handleBreakingNewsAlert() {
		if(driver.findElement(By.xpath("//a[@class=\"notnow\"]")).isDisplayed()) {
			driver.findElement(By.xpath("//a[@class=\"notnow\"]")).click();
		}
	}
}
