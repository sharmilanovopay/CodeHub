package com.testvagrant.WeathreComparator.Compare;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;

import org.testng.annotations.Test;

import com.testvagrant.Utils.Utils;
import com.testvagrant.WeatherComparator.API.ExtractTemperatureFromAPITest;
import com.testvagrant.WeatherComparator.UI.ExtractTemperatureFromUITest;

import resources.InputData;

public class CompareWeatherInfo extends Utils implements Comparator<Float> {

	static ExtractTemperatureFromAPITest api = new ExtractTemperatureFromAPITest();
	static ExtractTemperatureFromUITest ui = new ExtractTemperatureFromUITest();
		
	static float tempUsingAPI;
	static float tempUsingUI;
		
	public int compare(Float tempUsingAPI, Float tempUsingUI) {
		float difference;
		if(tempUsingAPI>=tempUsingUI) {
			difference = tempUsingAPI - tempUsingUI ;
		}else {
			difference = tempUsingUI - tempUsingAPI;
		}
		return Math.round(difference);
	}

	@Test(priority=1,dataProviderClass= InputData.class, dataProvider = "testData")
	public static void displayOutput(String City) throws IOException, InterruptedException {
		tempUsingAPI = api.getWeatherThroughAPI(City);
		tempUsingUI = ui.getWeatherThroughUI(City);
		CompareWeatherInfo CWI = new CompareWeatherInfo();
		int ActualResult = CWI.compare(tempUsingAPI,tempUsingUI);
		FileReader fis = new FileReader("C:\\Users\\Sharmila\\eclipse-workspace\\WeatherComparator\\Variance.txt");
		BufferedReader bufferedReader = new BufferedReader(fis);
		int Variance = Integer.parseInt(bufferedReader.readLine());
		bufferedReader.close();
		System.out.println("Actual Difference in the Temperatures = "+ActualResult+"\nVariance = "+ Variance);
		if (Variance >= ActualResult) {
			System.out.println("SUCCESS ! \nTemperature has matched between API and UI");
		}else {
			System.out.println("Exception");
		}
		
	
	}
	
	

}
