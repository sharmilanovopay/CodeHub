package com.testvagrant.WeathreComparator.Compare;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;

import org.testng.annotations.Test;

import com.testvagrant.Utils.Utils;
import com.testvagrant.WeatherComparator.API.ExtractTemperatureFromAPITest;
import com.testvagrant.WeatherComparator.UI.ExtractTemperatureFromUITest;

import resources.InputData;

public class CompareWeatherInfo extends Utils implements Comparator<Float> {

	static ExtractTemperatureFromAPITest api = new ExtractTemperatureFromAPITest();
	static ExtractTemperatureFromUITest ui = new ExtractTemperatureFromUITest();
		
	static float tempUsingAPI;
	static float tempUsingUI;
			
	public int compare(Float tempUsingAPI, Float tempUsingUI) {
		float difference;
		if(tempUsingAPI>=tempUsingUI) {
			difference = tempUsingAPI - tempUsingUI ;
		}else {
			difference = tempUsingUI - tempUsingAPI;
		}
		return Math.round(difference);
	}

	//Method to compare the temperature fetched from the UI and the API tests
	@Test(priority=1,dataProviderClass= InputData.class, dataProvider = "testData")
	public static void displayOutput(String City) throws IOException, InterruptedException {		
		tempUsingUI = ui.getWeatherThroughUI(City);
		tempUsingAPI = api.getWeatherThroughAPI(City);
		CompareWeatherInfo CWI = new CompareWeatherInfo();
		int ActualResult = CWI.compare(tempUsingAPI,tempUsingUI);
		FileReader fis = new FileReader("./Variance.txt");
		BufferedReader bufferedReader = new BufferedReader(fis);
		
		try {
		int TemperatureVariance = Integer.parseInt(bufferedReader.readLine());

		bufferedReader.close();
		System.out.println("Actual Difference in the Temperatures fetched through UI and API = "+ActualResult+"\nVariance = "+ TemperatureVariance);
		
		 
		if (TemperatureVariance >= ActualResult) {
			System.out.println("SUCCESS ! \nTemperature has matched");
		}else {
			System.out.println("Temperature information from the API and the UI are not matching");
		}
		}catch(Exception e) {
			System.out.println("Only whole numbers are accepted for the variance field");
		}
		
	}
	
	

}
