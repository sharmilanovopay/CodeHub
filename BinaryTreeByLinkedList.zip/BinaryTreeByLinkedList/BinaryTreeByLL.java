package BinaryTree;
import BinaryTree.BinaryNode;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTreeByLL {
    BinaryNode root;


    public static void main(String[] args) {
        BinaryTreeByLL BT = new BinaryTreeByLL();
        for (int i=1;i<6;i++){
            BT.insert(i*100);
        }
        System.out.println("BT.getDeepestNode() = "+BT.getDeepestNode());

        System.out.println("BT.preOrder(BT.root) -> ");
        BT.preOrder(BT.root);
        System.out.println();

        BT.deleteDeepestNode();

        System.out.println("BT.preOrder(BT.root) -> ");
        BT.preOrder(BT.root);
        System.out.println();

        BT.insert(600);
        System.out.println("BT.postOrder(BT.root) -> ");
        BT.postOrder(BT.root);
        System.out.println();

        BT.deleteNode(200);

        BT.insert(700);

        System.out.println("BT.preOrder(BT.root) -> ");
        BT.preOrder(BT.root);
        System.out.println();

        System.out.println("BT.InOrder(BT.root) -> ");
        BT.inOrder(BT.root);
        System.out.println();

        System.out.println("BT.levelOrder(BT.root) -> ");
        BT.levelOrder();

        BT.search(300);
        BT.deleteTree();

        BT.insert(800);

        System.out.println("BT.InOrder(BT.root) -> ");
        BT.inOrder(BT.root);
        System.out.println();
    }


    BinaryTreeByLL(){
        this.root=null;
    }

    public void insert(int value){
        BinaryNode node = new BinaryNode();
        node.setValue(value);
        if(root==null){
            root=node;
            System.out.println(value+" added in the root node");
            return;
        }else{
            Queue<BinaryNode> queue = new LinkedList<BinaryNode>();
            queue.add(root);
            while (!queue.isEmpty()) {
                BinaryNode presentNode = queue.remove();
                if (presentNode.getLeft() == null) {
                    presentNode.setLeft(node);
                    System.out.println(value +" added in left node");
                    return;
                } else if (presentNode.getRight() == null) {
                    presentNode.setRight(node);
                    System.out.println(value+" added in right node");
                    return;
                } else {
                    queue.add(presentNode.getLeft());
                    queue.add(presentNode.getRight());
                }
            }
        }
    }

    public void search(int value) {
        Queue<BinaryNode> queue = new LinkedList<BinaryNode>();
        queue.add(root);
        while (!queue.isEmpty()) {
            BinaryNode presentNode = queue.remove();
            if (presentNode.getValue() == value) {
                System.out.println("the value "+value +" is found ");
                return;
            } else {
                if (root.getLeft() != null) {
            queue.add(presentNode.getLeft());
                }
                if (root.getRight() != null) {
            queue.add(presentNode.getRight());
        }
    }
        }
        System.out.println("not found");
    }


    public void levelOrder(){
        Queue<BinaryNode> q=new LinkedList<BinaryNode>();
        q.add(root);
        BinaryNode presentNode;
        while(!q.isEmpty()){
            presentNode=q.remove();
            System.out.print(presentNode.getValue()+" ");
            if(presentNode.getLeft()!=null){
                q.add(presentNode.getLeft());
            }
            if(presentNode.getRight()!=null){
                q.add(presentNode.getRight());
            }
        }
        System.out.println();
    }

    public void deleteTree(){
        root=null;
        System.out.println("the tree is deleted");
    }

    public void inOrder(BinaryNode startingNode){
        if(startingNode==null){
            return;
        }else{
            inOrder(startingNode.getLeft());
            System.out.print(startingNode.getValue()+" ");
            inOrder(startingNode.getRight());
        }
    }

    public void preOrder(BinaryNode StartingNode){
        if(StartingNode==null){
            return;
        }else{
            System.out.print(StartingNode.getValue()+" ");
            preOrder(StartingNode.getLeft());
            preOrder(StartingNode.getRight());
        }
    }

    public void postOrder(BinaryNode StartingNode){
        if(StartingNode==null){
            return;
        }else{
            postOrder(StartingNode.getLeft());
            postOrder(StartingNode.getRight());
            System.out.print(StartingNode.getValue()+" ");
        }
    }

    public BinaryNode getDeepestNode(){
        Queue<BinaryNode> q = new LinkedList<BinaryNode>();
        q.add(root);
        BinaryNode presentNode=null;
        while(!q.isEmpty()){
            presentNode=q.remove();

            if(presentNode.getLeft()!=null){
                q.add(presentNode.getLeft());
            }
            if(presentNode.getRight()!=null){
                q.add(presentNode.getRight());
            }
        }
        return presentNode;
    }

    public void deleteDeepestNode(){
        Queue<BinaryNode> q= new LinkedList<BinaryNode>();
        q.add(root);
        BinaryNode previousNode,presentNode=null;
        while (!q.isEmpty()){
            previousNode=presentNode;
            presentNode=q.remove();
            if(presentNode.getLeft()==null){
                previousNode.setRight(null);
                System.out.println("deepest node deleted which was the last right node");
                return;
            }
            else if(presentNode.getRight()==null){
                previousNode.setLeft(null);
                System.out.println("deepest node deleted which was the last left node");
                return;
            }
            q.add(presentNode.getLeft());
            q.add(presentNode.getRight());
        }
    }

    public void deleteNode(int value){
        Queue<BinaryNode> q = new LinkedList<BinaryNode>();
        q.add(root);
        while(!q.isEmpty()){
            BinaryNode presentNode=q.remove();
            if(presentNode.getValue()==value){
                System.out.println("deepest node will be deleted and the value will be swapped in the value of the node that is to be deleted");
                presentNode.setValue(getDeepestNode().getValue());
                deleteDeepestNode();
                System.out.println("node with value "+value+" is deleted");
                return;
            }else{
                if(presentNode.getLeft()!=null){
                    q.add(presentNode.getLeft());
                }
                if(presentNode.getRight()!=null){
                    q.add(presentNode.getRight());
                }
            }
        }
        System.out.println("didnt find the value");
    }
}







